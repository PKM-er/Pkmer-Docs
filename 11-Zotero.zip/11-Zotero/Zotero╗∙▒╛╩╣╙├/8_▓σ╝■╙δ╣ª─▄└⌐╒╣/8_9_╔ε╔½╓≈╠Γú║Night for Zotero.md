---
uid: 20230817144026
title: 8.9- 深色主题：Night for Zotero
tags: [zotero]
description: 
author: winding,Ali,ShareStuff
type: other
draft: false
editable: false
modified: 20230817193221
---

# 8.9- 深色主题：Night for Zotero

## 一、需要做的准备

### （一）插件名称

 Night for Zotero

### （二）项目地址

 [https://github.com/tefkah/zotero-night](https://github.com/tefkah/zotero-night)

### （三）具体配置

 ![4570618973ccb95676c0ff60d0687b0e_MD5](https://cdn.pkmer.cn/images/202308171546181.png!pkmer)![72fd63d5ddc0dc9f022210a2d2f967bb_MD5](https://cdn.pkmer.cn/images/202308171546182.png!pkmer)

## 二、简单上手操作

![462860748c98ee4b8111d9cbae3732bb_MD5](https://cdn.pkmer.cn/images/202308171546183.png!pkmer)

![190d8a95195fdf64899c4e66c108b67c_MD5](https://cdn.pkmer.cn/images/202308171546184.png!pkmer)

下一篇 [[8_10_护眼模式：ZoteroTheme]]