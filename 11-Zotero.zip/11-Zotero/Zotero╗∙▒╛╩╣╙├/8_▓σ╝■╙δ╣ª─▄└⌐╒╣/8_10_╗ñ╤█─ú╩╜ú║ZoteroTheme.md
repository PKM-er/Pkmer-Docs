---
uid: 20230817144053
title: 8.10- 护眼模式：ZoteroTheme
tags: [zotero]
description: 
author: 摸鱼仙人,ShareStuff
type: other
draft: false
editable: false
modified: 20230817193410
---

# 8.10- 护眼模式：ZoteroTheme

## 一、需要做的准备

### （一）插件名称

 ZoteroTheme

### （二）项目地址

[https://github.com/iShareStuff/ZoteroTheme](https://github.com/iShareStuff/ZoteroTheme)

### （三）具体配置

 护眼模式绿色

 #b4efc3

 #40808080

## 二、上手操作

 编辑 - 首选项 -Theme （修改完不要忘记点 Apply 哦）

![3f8a7d3b2d51c7a192f4c013f8490aa8_MD5](https://cdn.pkmer.cn/images/202308171547848.png!pkmer)

## 三、恢复默认

编辑 - 首选项 -Theme

## 四、其他护眼模式

银河白 #FFFFFF RGB(255, 255, 255)

杏仁黄 #FAF9DE RGB(250, 249, 222)

秋叶褐 #FFF2E2 RGB(255, 242, 226)

胭脂红 #FDE6E0 RGB(253, 230, 224)

青草绿 #E3EDCD RGB(227, 237, 205)

海天蓝 #DCE2F1 RGB(220, 226, 241)

葛巾紫 #E9EBFE RGB(233, 235, 254)

极光灰 #EAEAEF RGB(234, 234, 239)

下一篇 [[9-常见问题]]