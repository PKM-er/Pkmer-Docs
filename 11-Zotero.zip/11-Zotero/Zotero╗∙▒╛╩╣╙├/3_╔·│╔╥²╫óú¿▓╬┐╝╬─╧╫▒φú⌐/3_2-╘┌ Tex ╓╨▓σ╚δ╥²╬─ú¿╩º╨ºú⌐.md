---
uid: 20230817141334
title: 3.2- 在 Tex 中插入引文（失效）
tags: []
description: 
author: 
type: other
draft: false
editable: false
modified: 20230817184435
---

# 3.2- 在 Tex 中插入引文（失效）

下一篇 [[3_3-直接导出参考文献表]]