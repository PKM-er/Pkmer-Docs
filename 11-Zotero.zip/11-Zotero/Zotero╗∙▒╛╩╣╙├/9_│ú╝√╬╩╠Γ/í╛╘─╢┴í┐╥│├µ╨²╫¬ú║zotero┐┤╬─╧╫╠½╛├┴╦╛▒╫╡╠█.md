---
uid: 20230817145130
title: 【阅读】页面旋转：zotero 看文献太久了颈椎疼
tags: [zotero]
description: 
author: 摸鱼仙人,ShareStuff
type: other
draft: false
editable: false
modified: 20230817161334
---

# 【阅读】页面旋转：zotero 看文献太久了颈椎疼

## 一、单面旋转

在显示缩略图里面右键

![56ba48c20de6e6bc635e3602edbee08f_MD5](https://cdn.pkmer.cn/images/202308171550268.png!pkmer)

## 二、全部文档进行旋转（注：在 6.0.16 版本更新已经没有了）

学习太久要注意休息哦，左转转右转转

在阅读界面，鼠标点到文献上，按快捷键 R 可以快速旋转

![8ea540a0211f1509b2dd58a49d0c4039_MD5](https://cdn.pkmer.cn/images/202308171550269.png!pkmer)
