功能简介
====

:::success

*   追踪期刊目录更新
*   追踪数据库中某些【关键词】相关的文献更新情况
*   订阅任意网站的内容更新，例如b站up主的视频更新... :::

1.Zotero订阅设置
============

在Zotero主界面，左上角工具栏选择![[Resource/Images/8eaf1075ad6e7d0388d8022378be4104_MD5.png]]**\=>新建订阅=>来自URL订阅**  
![[Resource/Images/082e0b99f33671fcef57049f895f32bc_MD5.png]]  
之后会弹出以下窗口，需要填入**URL，**zotero识别成功之后会自动填入**标题（**可以自己手动更改）并且进行**高级设置，保存**之后即可在主界面左侧**订阅**处看到订阅的内容及更新\*\*。\*\*  
![[Resource/Images/ca1753b4babad7b57128491010c88603_MD5.png]] 
![[Resource/Images/730ef05e6659e38ddb5e45eb1699a305_MD5.png]]

1.1 URL订阅
---------

**“来自URL”是最直接、最方便的添加RSS订阅的方式，只需要提供订阅源的链接即可，是我们用zotero追踪期刊更新时最常用的方式，以下涉及的实例也将基于此方式进行。**

1.2 OPML订阅
----------

“**来自OPML**”主要用于之前有使用其它RSS阅读器，从其它阅读器中导入已经订阅的内容至Zotero中，一般用户不会使用此方式，故不过多介绍。

1.3 高级设置
--------

![[Resource/Images/10e6c4cc538bf6d619c5424cfc7919b4_MD5.png]] 
【更新订阅每**N**小时】，即设定订阅间隔，每**N**个小时从订阅URL爬取期刊目录，加载在该【订阅】界面。例如《社会学研究》为双月刊，建议从其发刊日时添加订阅，N设定为2X30X24小时。如果N设置为24，则每24小时会刷新一遍订阅，订阅界面会24小时加载一次期刊目录，导致期刊【订阅】界面出现重复文献条目。以下为【订阅】界面因为设置**订阅间隔N**并不契合期刊更新间隔时出现的条目重复示例。  
![[Resource/Images/fc83ef0fc4c195163e3374add2dde7b8_MD5.png]]:::danger 订阅间隔设置不当导致的条目重复问题尚未完美的解决方案，只能根据期刊更新周期设定订阅间隔 :::

【删除已读提要题目于之后N天】，即点击了该条目查看右侧的条目详细信息（zotero会自动设置为“已读”状态）N天后在期刊订阅界面删除该条目，如果不想删除已读条目，则将N设置为一个较大的数值，例如1000000。  
【删除未读提要条目于之后N天】，即该条目一直处于未点击查看该条目的具体信息，N天后在期刊订阅界面删除该条目。如果不想删除未读条目，则将N设置为一个较大的数值，例如1000000。  
以上三项订阅参数的默认设置入口：  
Win：**编辑=>首选项=>高级=>订阅**  
Mac：**Zotero=>首选项=>高级=>订阅**  
![[Resource/Images/9304e915a8b7c5cc2f041ffdb3ee8621_MD5.png]]

1.4 填入URL后不能自动识别与保存的解决方法
------------------------

检查或更换网络，重启zotero后第一时间进入订阅填入URL，能够自动识别并填充标题即可成功订阅；部分URL需要在科学网络的情况下才能识别成功，因此此时需要保证自己的网络足够科学。

2.中文期刊订阅——以知网为例
===============

进入[知网期刊导航界面](https://navi.cnki.net/knavi/journals/index?uniplatform=NZKPT)，在【搜索框🔍】输入想要订阅的【中文期刊全称】，并点击【出版来源检索】  
![[Resource/Images/da18f8204bcc54e5e23b0d872c8cebf3_MD5.png]] 
在搜索结果界面，点击进入期刊页面  
![[Resource/Images/2713c50c5c7f8fdfdfb5c3453140cbad_MD5.png]] 
在期刊主页左上角找到并点击【RSS订阅】  
![[Resource/Images/5774166608c2acd40e3b0b4a9567382a_MD5.png]] 
复制浏览器地址栏中的URL，进入zotero  
![[Resource/Images/c24ac0c0b7933294a2d4a7e44911d58e_MD5.png]] 
在Zotero主界面，左上角工具栏选择![[Resource/Images/8eaf1075ad6e7d0388d8022378be4104_MD5.png]]**\=>新建订阅=>来自URL订阅，在弹出的界面填入URL，自动识别好标题之后自己根据需要修改标题**（zotero不会根据期刊订阅先后排序，可以手动在期刊名前面加上1234或者字母来排序），并且设置好订阅参数，点击【保存】，即可在左侧订阅界面看到该期刊的目录  
![[Resource/Images/10e6c4cc538bf6d619c5424cfc7919b4_MD5.png]] 
![[Resource/Images/5deb362d0f301aeaa644edb845097986_MD5.png]]

3.英文期刊订阅——以Annual Review of Psychology为例
========================================

打开[Annual Review of Psychology](https://www.annualreviews.org/journal/psych)网页，找到右上角的RSS feed![[Resource/Images/4f0264b6bf5ddf90c6a20140fe9cdbec_MD5.png]]符号，点击打开  
![[Resource/Images/6ca212e8ad546bf8e78f7238f013c1d5_MD5.png]] 
打开之后如下图示，**复制浏览器地址栏的URL链接**  
![[Resource/Images/3b6031e630e61050c467c93ae784ede8_MD5.png]] 
在Zotero主界面，左上角工具栏选择![[Resource/Images/8eaf1075ad6e7d0388d8022378be4104_MD5.png]]**\=>新建订阅=>来自URL订阅，在弹出的窗口中把刚刚复制的链接粘贴到“URL”中，**zotero会自动识别并填入标题（标题出来之后自己可以自定义修改）**，并参照本章1.3设置好高级选项**的内容，**点击保存**，即可在主界面\*\*“订阅”\*\*处看到该期刊的最新期刊目录。  
![[Resource/Images/3813a8257e7b3fd3d56f8b939b771aa3_MD5.png]]

4.关键词订阅（PubMed专属）
=================

打开[PubMed](https://pubmed.ncbi.nlm.nih.gov/) 官网，在搜索栏输入你想追踪的文献关键词，例如“heat wave”，点击搜索  
![[Resource/Images/76476691f0dd6c8b7661f5588e014179_MD5.png]] 
如下图示，点击搜索框下面的\*\*“Create RSS”，进入该关键词订阅的设置界面\*\*  
![[Resource/Images/533140fea0521e4a12faf26ba024a357_MD5.png]] 
在设置界面，修改为合适“Number of items displayed”（追踪的文献条目数量），点击\*\*“Create RSS”,生成“RSS Feed link”后点击copy，将其在zotero订阅设置中填入，\*\*即可订阅追踪该关键词的相关文献进展。![[Resource/Images/13c8093a607ab7817facf555042b910d_MD5.png]]

5.配合RSSHub Radar订阅任意网站内容——以b站为例
===============================

5.1 RSSHub Radar 简介
-------------------

RSSHub Radar 是 [RSSHub](https://www.appinn.com/rssbud-with-rsshub-for-ios/) 的衍生项目，用来快速发现当前网页的 RSS 地址，如果支持 RSSHub 则显示 RSSHub 地址，支持包括**Zotero**、 [Tiny Tiny RSS](https://www.appinn.com/tiny-tiny-rss/)、FreshRSS、Feedly、Inoreader 在内的 11 款阅读器一键订阅。  
主要功能：

*   快速发现和订阅当前页面自带的 RSS
*   快速发现和订阅当前页面支持的 RSSHub
*   快速发现当前网站支持的 RSSHub
*   支持一键订阅 RSS 到Tiny Tiny RSS、Miniflux、FreshRSS、Feedly、Inoreader、Feedbin、The Old Reader、Feeds.Pub、本地阅读器

一旦检测出 RSS 地址，RSSHub Radar 就会在角标上显示出数量。  
**RSSHub Radar浏览器插件下载与安装（含教程）：**[**Github主页**](https://github.com/DIYgod/RSSHub-Radar)**、**[**Gitee镜像主页**](https://gitee.com/mirrors/RSSHub-Radar)

5.2 RSSHub Radar 与Zotero联动
--------------------------

![[Resource/Images/5229fb8d037591b820e8e9e404359eb6_MD5.png]] 
打开你想关注的UP主（以sharestuff为例），点击浏览器右上角的RSSHub Radar插件图标  
![[Resource/Images/549d2ee147e86ddd4a1324ebff206b12_MD5.png]] 
选择所需要订阅的内容，点击\*\*“复制”，进入zotero进行URL订阅\*\*即可

6.从“订阅”添加文献条目到“我的文库”/“群组”
=========================

![[Resource/Images/ac27a0e6bd78dc738225615b335b36ee_MD5.png]] 
点开zotero某一期刊/RSS订阅内容，点击具体条目，看到右侧的信息栏，**点击右侧信息栏的▽倒三角图标**，选择你想要保存到的本地文库文件夹📂/在线群组文件夹📂，再点击\*\*“添加到XXXX”\*\*，即可从订阅中添加到自己的文献库中。![[Resource/Images/e03b994c55d79a495dc989dcfc869cc5_MD5.png]]