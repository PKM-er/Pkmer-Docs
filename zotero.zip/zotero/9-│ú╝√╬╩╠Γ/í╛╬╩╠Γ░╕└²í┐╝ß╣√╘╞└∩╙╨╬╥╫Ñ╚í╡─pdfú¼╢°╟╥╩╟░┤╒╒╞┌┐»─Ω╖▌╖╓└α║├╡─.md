---
uid: 20230817145238
title: 【问题案例】坚果云里有我抓取的pdf，而且是按照期刊年份分类好的
tags: 
description: 
author: 
type: other
draft: false
editable: false
modified: 20230817145249
---

# 【问题案例】坚果云里有我抓取的 pdf，而且是按照期刊年份分类好的

0、总结
----

### （一）步骤

统一用 zotero 管理的格式，在不同步的情况下，备份一遍数据

用 zotflie 管理的方式对于 pdf 重新管理，copy 一份重新管理的到其他位置，再切换同步方案回 zoteor 管理格式

### （二）缺点

手动进行同步，切换有点麻烦，改换同步方案，坚果云流量 1g 可能不够用

### （三）优点

zotero 管理格式，所有终端都可以一键同步，因为 ipad 以及安卓是没有插件的，zotfile 管理格式不适用。坚果云每个月流量都会更新，不一定都要一下子全部切换回去，可以慢慢传

一、背景
----

- （一）之前是用 windows，在 E 盘新建了一个“zotero 云端同步”的文件夹，文件夹里就是按照期刊年份这样分类好的。用坚果云进行同步

- （二）中途换了 mac，之前同步的文件夹好像没有在 mac 上同步，现在 Mac 上有一个 zotero 文件夹，里面的 storage 文件夹里都是一些

![[Resource/Images/a77acd3f9e59a767ff088f8674d4f1a0_MD5.png]]

二、问题分析
------

由描述所知

- （一）window 上是采用的 zotflie 的管理方式进行同步

- （二）mac 上采用的是 zotero 自带的管理格式进行的同步

三、明确目的
------

坚果云里有我抓取的 pdf，而且是按照期刊年份分类好的

可以拆开进行依次解决

（一）问题 1：抓取的 pdf，而且是按照期刊年份分类好的

（二）问题 2：抓取的 pdf 进行第三方云盘的同步

四、解决问题
------

### （一）解决问题 1

已知 zotfile 插件可以实现在 zotero 管理格式下，进行（抓取的 pdf，而且是按照期刊 年份分类好的），但是要注意的一点是关闭自动同步，以及备份好相应的数据

1. 步骤一：采用 zotero 自带的命名方式以 webdav 格式进行同步

##### 原因有三

其一，以 zotero 自带的命名方式，多终端（win，mac）可以无阻进行同步，在一些安装不了插件的终端 （比如 ipad，以及以后的安卓）也可以进行使用，且同步不需要多余的操作

其二，（抓取的 pdf，而且是按照期刊 年份分类好的），虽然是 pdf 好看，看似有条理了，但是用 zotero 软件里面就可以进行查看了，是一样的效果。而且还不影响你用 zotfile 实现（抓取的 pdf，而且是按照期刊 年份分类好的），在不同步的情况下用 zotfile 改一下管理方式就可以了

其三，想要把笔记压在 pdf 本体上，会导致污染 pdf，而且也做不了多少笔记。再加上上从 chartro 作者那边得知，zotero 笔记的大小上限是 500k，所以我们采用 better notes（最近大佬有一波大的更新，敬请期待）的方式，联合 obsidian 进行管理，是一个不错的解决方式

2. 步骤二：如何确定目前采用的是哪种同步方案

[【同步】如何确定目前采用的是哪种同步方案](https://zotero.yuque.com/staff-gkhviy/zotero/agofi0?view=doc_embed)

3. 步骤三：windows 切换同步方案

[【同步】切换同步方案](https://zotero.yuque.com/staff-gkhviy/zotero/tmlhgh?view=doc_embed)

4. 步骤四：windows 通过 WebDAV 同步（这里以坚果云举例子）

[通过 WebDAV 同步](https://zotero.yuque.com/staff-gkhviy/zotero/lub19i?view=doc_embed)

5. 步骤五：widows 关闭同步，备份一遍数据。用 zotflie 管理的方式对于 pdf 重新管理，copy 一份重新管理的到其他位置，再切换同步方案回 zoteor 管理格式

6. 步骤六：在 mac 上进行同步刷新

### （二）解决问题 2

在（一）里面得到了 pdf 的文件夹，可以直接进行压缩，进行文件多端发送，也可以，放到坚果云上面同步

but,我咋觉得，这个问题的终极目的是采用，zotfile 管理格式，win mac 都用这一管理格式，实现文献管理查看。我没有 mac 电脑，我虚拟机里面的 mac 密码给忘了，没有进行实验，这个得问一下 [@winding(yuqueyonghuzbufdu)](/yuqueyonghuzbufdu)

不知道是不是下面这个，可以实现这个效果不，不过按照这个方法以后，ipad 和以后出得安卓就不能正常同步了。要进行取舍，至于发现更好得方法，以后再更新@

[通过 Zotfile 与第三方网盘备份](https://zotero.yuque.com/staff-gkhviy/zotero/ahcgci?view=doc_embed)