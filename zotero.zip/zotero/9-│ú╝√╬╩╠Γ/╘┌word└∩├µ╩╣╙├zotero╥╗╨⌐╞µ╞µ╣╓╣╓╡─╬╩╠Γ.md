---
uid: 20230817145306
title: 在 word 里面使用 zotero 一些奇奇怪怪的问题
tags: []
description: 
author: 
type: other
draft: false
editable: false
modified: 20230817145330
---

# 在 word 里面使用 zotero 一些奇奇怪怪的问题

### 一、word 的 zotero 被禁用了怎么办

以 Word 为例，点击程序左上角的【Office 按钮】

选择如下图所示的【Word 选项】

选择选项中的【加载项】

在【加载项】的【管理】菜单中，可以选择如下图不同的加载项

选择一个想设置的加载项，然后点击【转到】按钮

接下来出现的界面里可以勾选或者取消某些加载项的复选框，然后点击【确定】按钮

选择其中的【禁用项目】后可以启用被禁用的加载项内容

### 二、zotero word 插件在那个文件夹

`C:\\Program Files (x86)\\Zotero\\extensions\\zoteroWinWordIntegration@zotero.org\\install`

### 三、zotero 中文字处理软件加载不了 word，应该怎么办?

### 四、word 里面的 zotero 插件不能搜索文献，只能用经典视图选中文献怎么办

重新禁用再启用一下 Word 插件，不行再重装

估计设置的原因，可以新建一个 profile，或把 word 启动项中的 zotero.dotm 删除，重新添加，试试